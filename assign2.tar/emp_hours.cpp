#include "emp_hours.h"

// std::ostream& operator << (std::ostream& o, const Hours& h){
//   o << "day: " << h.day << " open_hour: " << h.open_hour << " close_hour: " << h.close_hour << std::endl; 
//   return o;
// }